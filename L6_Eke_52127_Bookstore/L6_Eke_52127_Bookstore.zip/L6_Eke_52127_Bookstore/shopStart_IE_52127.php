<!DOCTYPE html>
<html lang="pl">
<head>
<?php include 'PHP_IE\headPartHtml_IE.php'; ?>
<?php include 'PHP_IE\ifEnter_IE.php'; ?>
<?php include 'PHP_IE\base_IE.php'; ?>
<?php include 'PHP_IE\makeEnter_IE.php'; ?>
<?php include 'PHP_IE\ifDelete_IE.php'; ?>
<?php include 'PHP_IE\makeDelete_IE.php'; ?>

 </head>
 <body>
<header>
<?php include 'PHP_IE\header_IE.php'; ?>
</header>
<article>
<?php include 'PHP_IE\article_IE.php'; ?>
</article>
<footer>
<?php include 'PHP_IE\footer_IE.php'; ?>
</footer>
</body>
</html>