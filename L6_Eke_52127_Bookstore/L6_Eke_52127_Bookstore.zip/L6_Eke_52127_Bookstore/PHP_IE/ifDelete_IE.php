<?php
$delete = TRUE;
if (isset($_POST['delete'])) {$book_id=$_POST['delete'];} else {$delete = False;}
?>
