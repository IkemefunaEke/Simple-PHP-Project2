<?php
    $article = 'You can buy books here!<br>';
    $article .= 'Best Books in the world!<br>';
    $article .= 'Enjoy!<br>';
    echo $article;
    ?>