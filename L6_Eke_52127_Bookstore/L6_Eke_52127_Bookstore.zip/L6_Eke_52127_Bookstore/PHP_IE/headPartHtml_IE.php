<?php
    $head_Part = '<title> Store Welcome IE</title>';
    $head_Part .= '<meta charset="UTF-8">';
    $head_Part .= '<link rel="stylesheet" href="CSS_IE/IE_52127_CSS.css">';
    $head_Part .= '<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=neon|outline|emboss|shadow-multiple">
        <style>
        body {
        font-family: "Sofia", sans-serif;
        font-size: 30px;
        }
        </style>' ;
    echo $head_Part;
    ?>