<?php
    $username = 'root';
    $password = '';
    $server = 'localhost';
    $database = 'shopIE';
?>
