<?php include 'nav_IE.php'; ?>
<?php
    $footer = '<h6 class="font-effect-outline"> <strong> Winter 2021 <Strong></h6>';
    echo $footer;
    ?>
