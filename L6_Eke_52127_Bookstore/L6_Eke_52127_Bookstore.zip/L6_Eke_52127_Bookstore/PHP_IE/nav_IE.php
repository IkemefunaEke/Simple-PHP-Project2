<?php
    $nav = '<nav><ul>';
    $nav .= '<li><a href="shopStart_IE_52127.php">Main page</a></li>';
    $nav .= '<li><a href="./shopView_IE.php">View books</a></li>';
    $nav .= '<li><a href="shopAdd_IE.php">Add a book</a></li>';
    $nav .= '<li><a href="shopDelete_IE.php">Delete a book</a></li>';
    $nav .= '</ul></nav>';
    echo $nav;
    ?>