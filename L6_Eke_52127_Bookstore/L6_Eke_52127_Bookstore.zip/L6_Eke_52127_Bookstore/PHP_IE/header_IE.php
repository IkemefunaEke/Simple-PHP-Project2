<?php
    $header = '<h1 class="font-effect-neon"> Book Market IE</h1>';
    $header .= '<h3 class="font-effect-shadow-multiple"> Welcome to the bookstore IE </h3>';
    echo $header;
    ?>